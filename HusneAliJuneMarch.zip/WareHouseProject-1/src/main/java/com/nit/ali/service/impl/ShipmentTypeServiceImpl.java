package com.nit.ali.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.nit.ali.model.ShipmentType;
import com.nit.ali.repository.ShipmentTypeRepo;
import com.nit.ali.service.IShimentTypeService;

@Service
public class ShipmentTypeServiceImpl
implements IShimentTypeService
{
		@Autowired
		private ShipmentTypeRepo repo; //HAS-A

		@Override
		public Integer saveShipmentType(ShipmentType st) {
			// TODO Auto-generated method stub
				st=repo.save(st);
				Integer id=st.getId();
				return id;
			}
		@Override
		public List<ShipmentType> getAllShipmentTypes() {
			List<ShipmentType> list = repo.findAll();
			return list;
		}
		@Override
		public void deleteShipmentType(Integer id) {
			// TODO Auto-generated method stub
			repo.deleteById(id);
			
		}
		@Override
		public boolean isShimentTypeExist(Integer id) {
			// TODO Auto-generated method stub
			return repo.existsById(id);
		}
		@Override
		public Optional<ShipmentType> getOneShipmentType(Integer id) {
			// TODO Auto-generated method stub
			Optional<ShipmentType> opt=repo.findById(id);
			return opt;
		}
		@Override
		public void updateShipmentType(ShipmentType st) {
			repo.save(st); //UPDATE SQL..
			}
		@Override
		public List<Object[]> getShipmentTypeModeCount() {
			// TODO Auto-generated method stub
			List<Object[]> list=repo.getShipmentTypeModeCount();
			return list;
		}
		@Override
		public Page<ShipmentType> getAllShipmentTypeByPage(Pageable pageble) {
			// TODO Auto-generated method stub
			Page<ShipmentType> page= repo.findAll(pageble);
			return page;
		}
		
		
				



}
