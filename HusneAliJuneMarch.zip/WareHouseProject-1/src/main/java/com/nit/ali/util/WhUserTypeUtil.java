package com.nit.ali.util;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.springframework.stereotype.Component;

@Component
public class WhUserTypeUtil {
	public void generatePieChart(String path, List<Object[]> list) {
		// create DataSet and fill Details
		DefaultPieDataset dataset= new DefaultPieDataset();
		// fill nd Data
		for(Object ob[]:list) {
			dataset.setValue(ob[0].toString(), 
					Double.valueOf(ob[1].toString()));
		}
		// create JFreeChart Object by using ChartFactor
		JFreeChart jfreeChart=ChartFactory.createPieChart("WAREHOUSE",dataset);
		// convert this JFeeChart Object into Image Formate
		try {
			ChartUtils.saveChartAsPNG(new
					File(path+"/WhUserTypeA.png"), jfreeChart, 400, 250);
		} catch (IOException e) {
			e.printStackTrace();
		} }
	public void generateBarChart(String path, List<Object[]> list) {
		// create DataSet and fill Details
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
			// fill Details
		for( Object ob[]:list) {
			dataset.setValue(Double.valueOf(ob[1].toString()), ob[0].toString(), "");
		}
				// create JFreeChart Object by using ChartFactor
		JFreeChart chart = ChartFactory.createBarChart(
				"WareHouse User",
                "User Type", "x values", dataset);
				// convert this JFeeChart Object into Image Formate
		try {
			ChartUtils.saveChartAsPNG(new
					File(path+"/WhUserTypeB.png"), chart, 400, 250);
		} catch (IOException e) {
			e.printStackTrace();
		} 
			
	}
}
