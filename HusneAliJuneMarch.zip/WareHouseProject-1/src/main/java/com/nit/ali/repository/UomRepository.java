package com.nit.ali.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nit.ali.model.Uom;

public interface UomRepository extends 
		JpaRepository<Uom, Integer> {

}
