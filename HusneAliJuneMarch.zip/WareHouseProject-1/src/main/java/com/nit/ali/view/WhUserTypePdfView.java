package com.nit.ali.view;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.nit.ali.model.WhUserType;

public class WhUserTypePdfView extends AbstractPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> model, com.lowagie.text.Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		response.setHeader("Content-Disposition",
				"attachment;filename=WhUserType"
		//+AppUtil.getCurrentDateTime()+".xlsx"
		);
		List<WhUserType> list=(List<WhUserType>) model.get("list");
		// create elements
		Paragraph phg=new Paragraph("WareHouse");
		// add to documents
		PdfPTable table=new PdfPTable(9);
		table.addCell("ID");
		table.addCell("USER TYPE");
		table.addCell("USER CODE");
		table.addCell("USER FOR");
		table.addCell("USER EMAIl");
		table.addCell("USER CONTACT");
		table.addCell("USER ID TYPE");
		table.addCell("USER IF OTHER");
		table.addCell("ID NUMBER");
		
		
				for(WhUserType wh:list)	{
					table.addCell(wh.getId().toString());
					table.addCell(wh.getUserType());
					table.addCell(wh.getUserCode());
					table.addCell(wh.getUserFor());
					table.addCell(wh.getUserEmail());
					table.addCell(wh.getUserContact());
					table.addCell(wh.getUserIdType());
					table.addCell(wh.getUserIfOther());
					table.addCell(wh.getUserIdNum());
					
				}
				// add element to doument
				document.add(table);
				document.add(phg);

	}

	
}
