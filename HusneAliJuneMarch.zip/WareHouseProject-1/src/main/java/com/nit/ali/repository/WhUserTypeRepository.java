   package com.nit.ali.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nit.ali.model.WhUserType;

public interface WhUserTypeRepository extends 
		JpaRepository<WhUserType, Integer> {
		@Query("select count(userEmail) from WhUserType where"
				+ " userEmail=:userEmail ")
		public Integer getUserMailCount(String userEmail);
		@Query("select userType,count(userType) from WhUserType group by userType ")
		public List<Object[]> getUserTypeAndCount();
}
