package com.nit.ali.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nit.ali.model.Part;
import com.nit.ali.service.IPartService;
@Controller
@RequestMapping("/part")
public class PartController {
	@Autowired
	private IPartService service;
	// 1. Register
	@GetMapping("/register")
	public String showReg() {
		return "PartRegister";
	}
	// 2. Save Data
	@PostMapping("/save")
	public String savePart(
			@ModelAttribute Part part, Model model) {
		// CAll service method
		Integer id=service.savePart( part);
		// create message
		String message="PartRegister:" + id+":saved";
		// sent message to UI
		model.addAttribute("message", message);
		return "PartRegister";
	}
	/*
	// 3. FindAll Data and fetching data without pagination
	@GetMapping("/all")
	public String getAllParts(Model model) {
		// Call Service Layer
		List<Part> list=service.getAllPart();
		// send back to UI
		model.addAttribute("list", list);
		return "PartData";
	}
	 */
	// 3. find All Data and fetching data with pagination
	@GetMapping("/all")
	public String getAllParts(@PageableDefault(page=0, size=3)
	Pageable pageable,Model model) {
		Page<Part> page=service.getAllPartsByPage(pageable);
		model.addAttribute("page", page);
		return "PartData";
	}

	//4. delete by id : /st/delete?id=<val>
	@GetMapping("/delete")
	public String deletePart( 
			@RequestParam("id")Integer pid, //read param
			Model model
			) 
	{
		if(service.isPartExist(pid)) {
			//call service
			service.deletePart(pid);

			//create message
			String message = new StringBuffer()
					.append("Part '")
					.append(pid)
					.append("' Deleted!")
					.toString();

			//send to UI
			model.addAttribute("message", message);
		} else {
			model.addAttribute("message", pid+ " not found!!");
		}
		//latest data
		model.addAttribute("list", service.getAllParts());

		return "PartData";
	}
	/*
	//4.Delete Record
	//4. delete by id : /st/delete?id=<val>
		@GetMapping("/delete")
		public String deletePart( 
				@RequestParam("id")Integer pid, //read param
				Model model, Part part
				) 
		{
			if(service.isPartExist(pid)) {
				//call service
				service.deletePart(pid);

				//create message
				String message = new StringBuffer()
						.append("Part '")
						.append(pid)
						.append("' Deleted!")
						.toString();

				//send to UI
				model.addAttribute("message", message);
			} else {
				model.addAttribute("message", pid+ " not found!!");
			}
			 model.addAttribute("list", service.getAllParts(part));

			return "PartData";
		}*/
}
