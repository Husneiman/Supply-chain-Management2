package com.nit.ali.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nit.ali.model.OrderMethod;

public interface OrderMethodRepository
extends JpaRepository<OrderMethod, Integer>{
}