package com.nit.ali.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.nit.ali.model.WhUserType;

public interface WhyUserTypeService {
	
		Integer saveWhUserType(WhUserType whUserType);
		void updateWhUserType(WhUserType whUserType);
		  void deleteWhUserType(Integer id);
		 Optional<WhUserType> getOneWhUserType(Integer id);
			List<WhUserType> getAll();
			boolean isWhUserTypeExit(Integer id);
			boolean isWhUserTypeEmailExist(String getUserMailCount);
			List<Object []> getUserTypeAndCount();
				Page<WhUserType> getWhUserTypeByPage(Pageable ageable);
}
