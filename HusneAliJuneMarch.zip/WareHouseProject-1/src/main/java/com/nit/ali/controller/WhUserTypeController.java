package com.nit.ali.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.nit.ali.model.WhUserType;
import com.nit.ali.service.impl.WhUserTypeServiceImpl;
import com.nit.ali.util.WhUserTypeUtil;
import com.nit.ali.view.WhUserTypeExcelView;
import com.nit.ali.view.WhUserTypePdfView;
@Controller
@RequestMapping("/wh")
public class WhUserTypeController {
	@Autowired
	private WhUserTypeServiceImpl service;
	@Autowired
	private WhUserTypeUtil util;
	@Autowired
	private ServletContext sc;
	//1. show reg page
	@GetMapping("/register")
	public String showRegister() {
		return "WhUserTypeRegister";
	}
	//2. save
	@PostMapping("/save")
	public String saveShipmentType(
			@ModelAttribute WhUserType whUserType, Model model) {
		// CAll service method
		Integer id=service.saveWhUserType(whUserType);
		// create message
		String message="WhUserTypeRegister:" + id+":saved";
		// sent message to UI
		model.addAttribute("message", message);
		return "WhUserTypeRegister";
	}

	// 3. Show All records(Display All Data set)
	@GetMapping("/all")
	public String showAllWhyUserTye( @PageableDefault(page=0, size=3) 
	Pageable pageable, Model model) {
		// call service layer
		Page<WhUserType> page=service.getWhUserTypeByPage(pageable);
		// send back to UI
		model.addAttribute("page", page);
		return "WhUserTypeData";
		/* either you caan take this code or above code also
		 * 
		 * 	getCommonSetupForDataPage(model,pageable);
		 * 	return "WhUserTypeData";
		
		
		 * */
	}
	// 4. delete record
	@GetMapping("/delete")
	public String deleteWhUserType(
			@RequestParam("id") Integer wid,
			Model model
			)
	{
		String message = null;
		if(service.isWhUserTypeExit(wid)) {
			service.deleteWhUserType(wid);
			message = "Warehouse User '"+wid+"' Deleted";
		} else {
			message = "Warehouse User '"+wid+"' notexist";
		}
		getCommonSetupForDataPage( model, PageRequest.of(0,3));
		model.addAttribute("message", message);
		return "WhUserTypeData";
	}
	/**
	 * This method contains code for showing data
	 * at WhUserTypeData.html
	 *
	 */
	private void getCommonSetupForDataPage(Model model, 
			Pageable pageable) {
		//call service to fetch
		Page<WhUserType> page = service.getWhUserTypeByPage(pageable);
		//send it to ui
		model.addAttribute("page", page);
	}
	// 5. Edit page
	@GetMapping("/edit")
	public String showWhUserTypeEdit(
			// at here you are reading the id by using this method
			@RequestParam("id") Integer wid, Model model) {
			Optional<WhUserType> opt=service.getOneWhUserType(wid);
			String page=null;
			if(opt.isPresent()) {
				WhUserType whUserType=opt.get();
					model.addAttribute("whUserType", whUserType);
				page="WhUserTypeEdit";
			}else {
				page="redirect:all";
			}
		return page;
	}
	// 6. Update operation
	@PostMapping("/update")
	public String doWhUserTypeUpdate(
			@ModelAttribute WhUserType whUserType, Model model) {
			service.updateWhUserType(whUserType);
			model.addAttribute("message","this is data of:"+whUserType.getId()+"updated");
			getCommonSetupForDataPage( model, PageRequest.of(0,3));
		return "WhUserTypeData";
	}
	/* This method is used to execute either all rows url like excel
	 * or selected rows like
	 * if user click Export(EXCEL)All  then no id will came in the picture
	 * if user click Export(Excel) then id will came in the picture
	  ecxcel/ id=304?
	  */
	// 7. excel view
	@GetMapping("/excel")
	public ModelAndView excelWhUserType(@RequestParam(value="id", required=false) Integer wid) {
		ModelAndView m=new ModelAndView();
		m.setView(new WhUserTypeExcelView());
		// read data from the database
		// read data all 
		if(wid==null) {
			// export all daata 
			List<WhUserType> list=service.getAll();
			// add objcts
			m.addObject("list",list);
			
		}else {
			// export only one data
			Optional<WhUserType> opt=service.getOneWhUserType(wid);
			m.addObject("list", Arrays.asList(opt.get()));
			
			//m.addObject("list", List.of(opt.get()));
			
		}
		return m;
	}
		// 7. export in Pdf
		@GetMapping("/pdf")
		public ModelAndView exportPdfWhUserType(
				@RequestParam(value="id", required=false)Integer pid) {
				ModelAndView mdf=new ModelAndView();
				mdf.setView(new WhUserTypePdfView());
				if(pid==null) {
					// export all daata 
					List<WhUserType> list=service.getAll();
					// add objcts
					mdf.addObject("list",list);
					
				}else {
					// export only one data
					Optional<WhUserType> opt=service.getOneWhUserType(pid);
					mdf.addObject("list", Arrays.asList(opt.get()));
					
					//m.addObject("list", List.of(opt.get()));
					
				}

			return mdf;
		}
		// 8. Ajax Validation
		@GetMapping("/mail")
		public @ResponseBody String validateUserMail(
		@RequestParam String userEmail)
		{
		String msg="";
		if(service.isWhUserTypeEmailExist(userEmail)) {
		msg =userEmail + " already exist";
		}
		return msg;
		}
		// 9. Chart 
		@GetMapping("/charts")
		public String generateChart() {
			// call service method
			// get Data from DataBase BY using service
			List<Object[]> list=service.getUserTypeAndCount();
			// get Real Path
			String path=sc.getRealPath("");
			// call util method
			util.generatePieChart(path, list);
			util.generateBarChart(path, list);
			return "WhUserTypeCharts";
		}
		
}
