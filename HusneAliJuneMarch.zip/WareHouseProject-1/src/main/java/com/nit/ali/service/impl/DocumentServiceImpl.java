package com.nit.ali.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.ali.model.Document;
import com.nit.ali.repository.DocumentRepository;
import com.nit.ali.service.IDocumentService;
@Service
public class DocumentServiceImpl implements IDocumentService {
	@Autowired
	private DocumentRepository repo;
	public void saveDocument(Document doc) {
		repo.save(doc);
	}
	@Override
	public List<Object[]> getDocIdAndNames() {
		return repo.getDocIdAndNames();
	}
	public Optional<Document> getDocumentById(Integer id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}
		
	
		

}
