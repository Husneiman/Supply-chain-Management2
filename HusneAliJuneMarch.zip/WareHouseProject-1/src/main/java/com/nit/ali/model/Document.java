package com.nit.ali.model;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import lombok.Data;

//@Data
@Entity
@Table(name="doc_tab")
public class Document {
	@Id
	@Column(name="col_id_col")
	private Integer docId;
	@Column(name="col_name_col")
	private String docName;
	@Column(name="col_type_col")
	@Lob // byte[]+lob=blob
	private byte[] docData;
public Integer getDocId() {
		return docId;
	}
	public void setDocId(Integer docId) {
		this.docId = docId;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public byte[] getDocData() {
		return docData;
	}
	public void setDocData(byte[] docData) {
		this.docData = docData;
	}
	@Override
	public String toString() {
		return "Document [docId=" + docId + ", docName=" + docName + ", docData=" + Arrays.toString(docData) + "]";
	}
	
	
}
