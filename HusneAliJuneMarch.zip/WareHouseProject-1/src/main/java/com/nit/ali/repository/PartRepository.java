package com.nit.ali.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nit.ali.model.Part;

public interface PartRepository extends JpaRepository<Part, Integer> {

}
