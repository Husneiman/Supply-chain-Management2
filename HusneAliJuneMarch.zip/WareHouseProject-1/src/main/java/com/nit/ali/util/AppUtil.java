package com.nit.ali.util;

import java.text.SimpleDateFormat;
import java.util.Date;
//JAVA#8 static method allowed in interface
public interface AppUtil {
	public static String getCurrentDateTime() {
		return new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss")
				.format(new Date());
	}
}