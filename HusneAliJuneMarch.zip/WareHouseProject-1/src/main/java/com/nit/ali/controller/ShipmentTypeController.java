package com.nit.ali.controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nit.ali.model.ShipmentType;
import com.nit.ali.service.IShimentTypeService;
import com.nit.ali.util.ShipmentTypeUtil;
//import com.nit.ali.util.ShipmentTypeUtil;
import com.nit.ali.view.ShipmentTypeExcelOneView;
import com.nit.ali.view.ShipmentTypeExcelView;
import com.nit.ali.view.ShipmentTypePdfView;

@Controller
@RequestMapping("/st")
public class ShipmentTypeController {
	@Autowired
	private IShimentTypeService service;
	@Autowired
	private ShipmentTypeUtil util;
	@Autowired
	private ServletContext sc;
	//1. Show Register page
	@GetMapping("/register")
	public String showReg() {
		return "ShipmentTypeRegister";
	}

	//2. Onclick submit button and save the data
	@PostMapping("/save")
	public String saveShipmentType(
			@ModelAttribute ShipmentType shipmentType, Model model) {
		// CAll service method
		Integer id=service.saveShipmentType( shipmentType);
		// create message
		String message="ShipmentTypeRegister:" + id+":saved";
		// sent message to UI
		model.addAttribute("message", message);
		return "ShipmentTypeRegister";
	}
	//3. Display all rows
	@GetMapping("/all")
	public String showAllData(@PageableDefault( page=0, size=3) 
						Pageable pageable,Model model
			) {
			Page<ShipmentType> page=service.getAllShipmentTypeByPage(pageable);
			model.addAttribute("page", page);
		return "ShipmentTypeData";
	}
	/*@GetMapping("/all")
	public String viewAllShipmentsByPage(
	@PageableDefault(page = 0, size = 3) Pageable
	pageable, Model model ) {
		// call service layer
				// and fetch all Data from DataBase
				Page<ShipmentType> page =service.getAllShipmentTypeByPage(pageable);
				//send data to UI
				model.addAttribute("page", page);
				//Go back to UI page
				return "ShipmentTypeData";
			}*/
		// This is old code please see new code on above
	
	//3. Display all rows
	/*@GetMapping("/all")
	public String showAllShipmentTypes(
	Model model )
	{
	// call service layer
	List<ShipmentType> list =
	service.getAllShipmentTypes();
	//send data to UI
	model.addAttribute("list", list);
	//Go back to UI page
	return "ShipmentTypeData";
	}*/
	//4.  Delete Id and read this is by using Request param
	@GetMapping("/delete")

	public String deleteShipmentType(@RequestParam("id")Integer
			sid,Model model) {
		// check id exits or not
		if(service.isShimentTypeExist(sid)) {
			// call service layer
			service.deleteShipmentType(sid);
			// construct a message
			//String message=" delete shipmentType"+sid+ "Deleted";
			// construct  a message by using StringBuffer
			String message=new StringBuffer().append("shipmentType")
					.append(sid).append("Deleted")
					.toString();
			System.out.println("true");
			// Send to UI
			model.addAttribute("message", message);
		} else {
			model.addAttribute("message", sid+ "not found");
		}
		// get Latest Data
		model.addAttribute("list",service.getAllShipmentTypes());

		return "ShipmentTypeData";
	}
	//5. Edit  process
	@GetMapping("/edit")
	public String showShipmentTypeEdit(
			@RequestParam("id")Integer sid,
			Model model
			)
	{
		String page = null;
		Optional<ShipmentType> opt =
				service.getOneShipmentType(sid);
		if(opt.isPresent()) { //if data is present (not null)
			//object --> Fill in Form
			model.addAttribute("shipmentType", opt.get());
			page = "ShipmentTypeEdit";
		} else {
			// response.sendRedirect("/all");
			page = "redirect:all";
		}
		return page;
	}
	//6. Update Process
	@PostMapping("/update")
	public String doUpdateShipmentType(
			@ModelAttribute ShipmentType shipmentType,
			Model model)
	{
		//call service to update
		service.updateShipmentType(shipmentType);
		//return "redirect:all";
		//send message to UI
		model.addAttribute("message", "Shipment Type'"+shipmentType.getId()+"' Updated!!");
		// call service layer for latest data
		List<ShipmentType> list =
				service.getAllShipmentTypes();
		//send data to UI for HTML table
		model.addAttribute("list", list);
		//Go back to UI page
		return "ShipmentTypeData";
	}
	//7.export in excel file of all data
	@GetMapping("/excel")
	public ModelAndView excelExportData() {
		ModelAndView m=new ModelAndView();
		// feth data from shipment type class by using service
		List<ShipmentType> list=service.getAllShipmentTypes();
		//  set view
		m.setView(new ShipmentTypeExcelView());
		// add Object to model
		m.addObject("list",list);
		return m;
	}
	//8.export in excel only one data

	@GetMapping("/excelone")
	public ModelAndView showExcelOneExport(
			@RequestParam("id")Integer sid)
	{
		//fetch all rows from DB
		Optional<ShipmentType> opt =
				service.getOneShipmentType(sid);
		//create ModelAndView
		ModelAndView m = new ModelAndView();
		m.addObject("st", opt.get());
		m.setView(new ShipmentTypeExcelOneView());
		return m;
	}
	//9.Export pdf to document
	@GetMapping("/pdf")
	public ModelAndView exporttoPdf() {
		// get data from the database
		List<ShipmentType> list=service.getAllShipmentTypes();
		// creates modelandView Class Object
		ModelAndView m = new ModelAndView();
		// add object
		m.addObject("list",list);
		// set view
		m.setView(new ShipmentTypePdfView());

		return m;
	}
	//10.chaarts add below method
	@GetMapping("/charts")
	public String showCharts() {
		// call service for data
		List<Object[]> list =
				service.getShipmentTypeModeCount();
		// dynamic path inside server(runtime location)
		String path = sc.getRealPath("/"); //root location
		System.out.println("Runtime location=>" + path);
		// call util method for generation
		util.generatePieChart(path, list);
		util.generateBarChart(path, list);
		return "ShipmentTypeCharts.html";
	}

}
