package com.nit.ali.view;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsxView;

import com.nit.ali.model.WhUserType;
import com.nit.ali.model.WhUserType;
import com.nit.ali.util.AppUtil;

public class WhUserTypeExcelView extends AbstractXlsxView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model, 
			Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		Sheet sheet=workbook.createSheet("WhUser");
		response.setHeader("Content-Disposition",
	"attachment;filename=SHIPMENTS"+AppUtil.getCurrentDateTime()+".xlsx");
						setHead(sheet);
		@SuppressWarnings("unchecked")
		List<WhUserType> list=(List<WhUserType>)model.get("list");
		setBody(sheet,list);
		}

	private void setHead(Sheet sheet) {
		// TODO Auto-generated method stub
		// create first row in excel
		Row row=sheet.createRow(0);
		row.createCell(0).setCellValue("id");
		row.createCell(1).setCellValue("userType");
		row.createCell(2).setCellValue("userCode");
		row.createCell(3).setCellValue("userFor");
		row.createCell(4).setCellValue("userEmail");
		row.createCell(5).setCellValue("userContact");
		row.createCell(6).setCellValue("userIdType");
		row.createCell(7).setCellValue("userIfOther");
		row.createCell(8).setCellValue("userIdNum");
		//row.createCell(6).setCellValue("userIdType");
		
	}
	private void setBody(Sheet sheet, List<WhUserType> list) {
		// TODO Auto-generated method stub
		int RowNum=1;
		for(WhUserType st:list) {
			Row row=sheet.createRow(RowNum++);
			row.createCell(0).setCellValue(String.valueOf(st.getId()));
			row.createCell(1).setCellValue(st.getUserType());
			row.createCell(2).setCellValue(st.getUserCode());
			row.createCell(3).setCellValue(st.getUserFor());
			row.createCell(4).setCellValue(st.getUserEmail());
			row.createCell(5).setCellValue(st.getUserContact());
			row.createCell(6).setCellValue(st.getUserIdType());
			row.createCell(7).setCellValue(st.getUserIfOther());
			row.createCell(8).setCellValue(st.getUserIdNum());
			
			
			
			
			
		}
	}

	}