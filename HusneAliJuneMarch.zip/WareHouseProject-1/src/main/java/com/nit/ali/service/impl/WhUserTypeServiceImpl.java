package com.nit.ali.service.impl;

import java.awt.print.Pageable;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.nit.ali.model.WhUserType;
import com.nit.ali.repository.WhUserTypeRepository;
import com.nit.ali.service.WhyUserTypeService;
@Service
public  class WhUserTypeServiceImpl implements WhyUserTypeService {
	@Autowired
	private WhUserTypeRepository repo;

	@Override
	public Integer saveWhUserType(WhUserType whUserType) {
		// TODO Auto-generated method stub
		whUserType=repo.save(whUserType);
		Integer id=whUserType.getId();
		return id;
	}

	
	@Override
	public void updateWhUserType(WhUserType whUserType) {
		// TODO Auto-generated method stub
		repo.save(whUserType);
		
	}
	@Override
	public void deleteWhUserType(Integer id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
		
	}


	@Override
	public Optional<WhUserType> getOneWhUserType(Integer id) {
		// TODO Auto-generated method stub
					Optional<WhUserType> opt=repo.findById(id);
					return opt;
				}

	@Override
	public List<WhUserType> getAll() {
		List<WhUserType> list = repo.findAll();
		return list;
	}

	@Override
	public boolean isWhUserTypeExit(Integer id) {
		// TODO Auto-generated method stub
		return repo.existsById(id);
	}


	/*@Override
	public boolean isisWhUserTypeEmailExit(String userEmail) {
		// TODO Auto-generated method stub
		return repo.getUserMailCount(userEmail)>0;
		 
	}*/


	@Override
	public boolean isWhUserTypeEmailExist(String userEmail) {
		// TODO Auto-generated method stub
		return repo.getUserMailCount(userEmail)>0;
		}


	@Override
	public List<Object[]> getUserTypeAndCount() {
		// TODO Auto-generated method stub
		return repo.getUserTypeAndCount();
	}


	@Override
	public Page<WhUserType> getWhUserTypeByPage(org.springframework.data.domain.
			Pageable ageable) {
		// TODO Auto-generated method stub
		return repo.findAll(ageable);
	}


	


		}
