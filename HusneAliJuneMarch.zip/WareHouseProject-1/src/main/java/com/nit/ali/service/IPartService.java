package com.nit.ali.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.nit.ali.model.Part;
import com.nit.ali.model.Part;

public interface IPartService {
		Integer savePart(Part part);
		List<Part> getAllParts();
		void deletePart(Integer id);
		boolean isPartExist(Integer id);
		Page<Part> getAllPartsByPage(Pageable pageable);
		//Object getAllParts();
		}
