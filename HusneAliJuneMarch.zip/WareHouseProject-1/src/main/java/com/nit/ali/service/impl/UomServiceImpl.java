package com.nit.ali.service.impl;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.nit.ali.model.Uom;
import com.nit.ali.repository.UomRepository;
import com.nit.ali.service.IUomService;
@Service
public class UomServiceImpl implements IUomService {
			@Autowired
			private UomRepository repo;

			@Override
			public Integer saveUom(Uom uom) {
				// TODO Auto-generated method stub
				uom =repo.save(uom);
				return  uom.getId();
						}

			@Override
			public List<Uom> getAllUoms() {
				// TODO Auto-generated method stub
				List<Uom> list=repo.findAll();
				return list;}

			@Override
			public void deleteUom(Integer id) {
				// TODO Auto-generated method stub
				repo.deleteById(id);
				
			}

			@Override
			public boolean isUomExist(Integer id) {
				// TODO Auto-generated method stub
				
				return repo.existsById(id);
			}

			@Override
			public Optional<Uom> getOneUom(Integer id) {
				// TODO Auto-generated method stub
				Optional<Uom> opt=repo.findById(id);
				return opt;
			}

			@Override
			public void updateUom(Uom uom) {
				// TODO Auto-generated method stub
				repo.save(uom);
				
			}

			@Override
			public Page<Uom> getAllUomByPage(Pageable pageble) {
				// TODO Auto-generated method stub
				Page<Uom> page=repo.findAll(pageble);
				return page;
			}

			@Override
			public boolean isUomModelExistForEdit(String UomModel, Integer id) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public List<Object[]> getUomTypeAndCount() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Page<Uom> getAllUoms(Pageable p) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Page<Uom> findByUomModelContaining(String UomModel, Pageable pageable) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Map<Integer, String> getUomIdAndModel() {
				// TODO Auto-generated method stub
				return null;
			}

				}
