package com.nit.ali;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WareHouseProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(WareHouseProject1Application.class, args);
	}

}
