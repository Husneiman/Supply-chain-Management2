package com.nit.ali.controller;

import java.util.Optional;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nit.ali.model.Uom;
import com.nit.ali.service.IUomService;

@Controller
@RequestMapping("/uom")
public class UomController {
	@Autowired
	private IUomService service;
	@Autowired
	private ServletContext sc;
	//1. Show Register page
	@GetMapping("/register")
	public String showReg() {
		return "UomRegister";
	}

	//2. Onclick submit button and save the data
	@PostMapping("/save")
	public String saveUom(
			@ModelAttribute Uom Uom, Model model) {
		// CAll service method
		Integer id=service.saveUom( Uom);
		// create message
		String message="UomRegister:" + id+":saved";
		// sent message to UI
		model.addAttribute("message", message);
		return "UomRegister";
	}
	//3. Display all rows
	@GetMapping("/all")
	public String showAllData(@PageableDefault( page=0, size=3) 
						Pageable pageable,Model model
			) {
			Page<Uom> page=service.getAllUomByPage(pageable);
			model.addAttribute("page", page);
		return "UomData3";
	}
	/*@GetMapping("/all")
	public String viewAllShipmentsByPage(
	@PageableDefault(page = 0, size = 3) Pageable
	pageable, Model model ) {
		// call service layer
				// and fetch all Data from DataBase
				Page<Uom> page =service.getAllUomByPage(pageable);
				//send data to UI
				model.addAttribute("page", page);
				//Go back to UI page
				return "UomData3";
			}*/
		// This is old code please see new code on above
	
	//3. Display all rows
	/*@GetMapping("/all")
	public String showAllUoms(
	Model model )
	{
	// call service layer
	List<Uom> list =
	service.getAllUoms();
	//send data to UI
	model.addAttribute("list", list);
	//Go back to UI page
	return "UomData3";
	}*/
	//4.  Delete Id and read this is by using Request param
	@GetMapping("/delete")

	public String deleteUom(@RequestParam("id")Integer
			sid,Model model) {
		// check id exits or not
		if(service.isUomExist(sid)) {
			// call service layer
			service.deleteUom(sid);
			// construct a message
			//String message=" delete Uom"+sid+ "Deleted";
			// construct  a message by using StringBuffer
			String message=new StringBuffer().append("Uom")
					.append(sid).append("Deleted")
					.toString();
			System.out.println("true");
			// Send to UI
			model.addAttribute("message", message);
		} else {
			model.addAttribute("message", sid+ "not found");
		}
		// get Latest Data
		model.addAttribute("list",service.getAllUoms());

		return "UomData3";
	}
	/**
	 * This method contains code for showing data
	 * at WhUserTypeData.html
	 *
	 */
	private void getCommonSetupForDataPage(Model model, 
			Pageable pageable) {
		//call service to fetch
			Page<Uom> page=service.getAllUomByPage(pageable);
			model.addAttribute("page", page);
		}
	//5. Edit  process
	@GetMapping("/edit")
	public String showUomEdit(
			@RequestParam("id")Integer sid,
			Model model) {
		Optional<Uom> opt=service.getOneUom(sid);
		String page=null;
		if(opt.isPresent()) {
			Uom uom=opt.get();
				model.addAttribute("uom", uom);
			page = "UomEdit";
		} else {
			// response.sendRedirect("/all");
			page = "redirect:all";
		}
		return page;
	}
	//6. Update Process
	@PostMapping("/update")
	public String doUpdateUom(
			@ModelAttribute Uom uom,
			Model model)
	{
		//call service to update
		service.updateUom(uom);
		//return "redirect:all";
		//send message to UI
		model.addAttribute("message", "Uom Type'"+uom.getId()+"' Updated!!");
		// call service layer for latest data
		getCommonSetupForDataPage( model, PageRequest.of(0,3));
		return "UomData3";
	}

}
