package com.nit.ali.view;

import java.awt.Color;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.nit.ali.model.ShipmentType;

public class ShipmentTypePdfView extends AbstractPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> model,
			Document document, PdfWriter writer,
			HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		//response.setHeader("Content-disposition",	"attachment;filename=Shipment.pdf");
		// taking font 
		Font font=new Font( Font.HELVETICA, 18, Font.BOLD, Color.BLUE);
			// create element by using paragraph
		Paragraph p=new Paragraph("welcome to sample",font);
		// need to add in document files
		p.setAlignment(Element.ALIGN_CENTER);
		document.add(p);
		// read data from the databse
		List<ShipmentType> list=(List<ShipmentType>) model.get("list");
		@SuppressWarnings("uncheked")
		PdfPTable table=new PdfPTable(6);// at here no of columns is 6
		setHead(table);
		setBody(table,list);
		document.add(table);
		Font font2=new Font( Font.HELVETICA, 18, Font.BOLD, Color.BLUE);
		document.add(new Paragraph(new Date().toString(),font2));
	}

	private void setHead(PdfPTable table) {
		// TODO Auto-generated method stub
		Font font=new Font( Font.HELVETICA, 8, Font.BOLD, Color.BLACK);
		table.addCell(new Phrase("ID",font));
		table.addCell(new Phrase("MODE",font));
		table.addCell(new Phrase("CODE",font));
		table.addCell(new Phrase("ENABLE",font));
		table.addCell(new Phrase("GRADE",font));
		table.addCell(new Phrase("DESCRIPTION",font));
		
		
	}
	private void setBody(PdfPTable table,	List<ShipmentType> list) {
		// TODO Auto-generated method stub
		Font font=new Font( Font.HELVETICA, 8, Font.BOLD, Color.BLACK);
		for(ShipmentType st:list) {
			table.addCell(new Phrase(st.getId().toString(),font));
			table.addCell(new Phrase(st.getShipmentMode(),font));
			table.addCell(new Phrase(st.getShipmentCode(),font));
			table.addCell(new Phrase(st.getEnableShipment(),font));
			table.addCell(new Phrase(st.getShipmentGrade(),font));
			table.addCell(new Phrase(st.getShipmentDescription(),font));
			
		}
	}
	

}
