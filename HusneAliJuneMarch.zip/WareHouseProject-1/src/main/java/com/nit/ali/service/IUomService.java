package com.nit.ali.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.nit.ali.model.Uom;

public interface IUomService {
	Integer saveUom(Uom Uom);
	
	List<Uom> getAllUoms();
	public void deleteUom(Integer id);
	 boolean isUomExist(Integer id);
	Optional<Uom> getOneUom(Integer id);
	void updateUom(Uom Uom);
	Page<Uom> getAllUomByPage(Pageable pageble);
	//-----------------------for Part Module--------------------
	//public boolean isUomModelExist(String UomModel);
	public boolean isUomModelExistForEdit(String UomModel,Integer id);
	
	public List<Object[]> getUomTypeAndCount();
	public Page<Uom> getAllUoms(Pageable p);
	public Page<Uom> findByUomModelContaining(String UomModel,Pageable pageable);
	
	
	public Map<Integer,String> getUomIdAndModel(); 
	

}
