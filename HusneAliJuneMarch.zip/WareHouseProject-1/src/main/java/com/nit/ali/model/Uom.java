package com.nit.ali.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
//@Data
@Table(name="user_model_Type")
public class Uom {
	@Id
	@GeneratedValue
	@Column(name="mod_type_id")
	private Integer id;
	@Column(name="mod_type_col")
	private String modelType;
	@Column(name="mod_type_addr")
	private String modelTypeAddr;
	@Column(name="mod_type_desc")
	private String modelTypeDesc;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getModelType() {
		return modelType;
	}
	public void setModelType(String modelType) {
		this.modelType = modelType;
	}
	public String getModelTypeAddr() {
		return modelTypeAddr;
	}
	public void setModelTypeAddr(String modelTypeAddr) {
		this.modelTypeAddr = modelTypeAddr;
	}
	public String getModelTypeDesc() {
		return modelTypeDesc;
	}
	public void setModelTypeDesc(String modelTypeDesc) {
		this.modelTypeDesc = modelTypeDesc;
	}
	}
