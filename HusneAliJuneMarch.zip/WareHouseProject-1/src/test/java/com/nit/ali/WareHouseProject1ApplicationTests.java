package com.nit.ali;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WareHouseProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
